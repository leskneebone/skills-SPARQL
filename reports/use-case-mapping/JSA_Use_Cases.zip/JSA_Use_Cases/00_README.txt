JSA Use Case Package

Contents:
- Credit Transfer use case
- Recognition of Prior Learning use case

These use cases describe operational scenarios that inform
skills data modelling and interoperability requirements.

Structure follows a TOGAF-aligned business scenario approach.

Prepared by: Les Kneebone
Date: [insert date]

